use crate::renderer::{wgpu_wrapper, RenderDevice, RenderQueue};
use bevy_derive::{Deref, DerefMut};
use bevy_ecs::{
    resource::Resource,
    world::{FromWorld, World},
};
use bevy_image::ImageSamplerDescriptor;
use bevy_utils::define_atomic_id;
use core::ops::Deref;

define_atomic_id!(TextureId);

wgpu_wrapper! {
    #[derive(Clone, Debug)]
    struct WgpuTexture(wgpu::Texture);
}

/// A GPU-accessible texture.
///
/// May be converted from and dereferences to a wgpu [`Texture`](wgpu::Texture).
/// Can be created via [`RenderDevice::create_texture`](crate::renderer::RenderDevice::create_texture).
///
/// Other options for storing GPU-accessible data are:
/// * [`BufferVec`](crate::render_resource::BufferVec)
/// * [`DynamicStorageBuffer`](crate::render_resource::DynamicStorageBuffer)
/// * [`DynamicUniformBuffer`](crate::render_resource::DynamicUniformBuffer)
/// * [`GpuArrayBuffer`](crate::render_resource::GpuArrayBuffer)
/// * [`RawBufferVec`](crate::render_resource::RawBufferVec)
/// * [`StorageBuffer`](crate::render_resource::StorageBuffer)
/// * [`UniformBuffer`](crate::render_resource::UniformBuffer)
#[derive(Clone, Debug)]
pub struct Texture {
    id: TextureId,
    value: WgpuTexture,
}

impl Texture {
    /// Returns the [`TextureId`].
    #[inline]
    pub fn id(&self) -> TextureId {
        self.id
    }

    /// Creates a view of this texture.
    pub fn create_view(&self, desc: &wgpu::TextureViewDescriptor) -> TextureView {
        TextureView::from(self.value.create_view(desc))
    }
}

impl From<wgpu::Texture> for Texture {
    fn from(value: wgpu::Texture) -> Self {
        Texture {
            id: TextureId::new(),
            value: WgpuTexture::new(value),
        }
    }
}

impl Deref for Texture {
    type Target = wgpu::Texture;

    #[inline]
    fn deref(&self) -> &Self::Target {
        &self.value
    }
}

define_atomic_id!(TextureViewId);

wgpu_wrapper! {
    #[derive(Clone, Debug)]
    struct WgpuTextureView(wgpu::TextureView);

    struct WgpuSurfaceTexture(wgpu::SurfaceTexture);
}

/// Describes a [`Texture`] with its associated metadata required by a pipeline or [`BindGroup`](super::BindGroup).
#[derive(Clone, Debug)]
pub struct TextureView {
    id: TextureViewId,
    value: WgpuTextureView,
}

pub struct SurfaceTexture {
    value: WgpuSurfaceTexture,
}

impl SurfaceTexture {
    pub fn present(self, render_queue: &RenderQueue) {
        render_queue.present(self.value.into_inner());
    }
}

impl TextureView {
    /// Returns the [`TextureViewId`].
    #[inline]
    pub fn id(&self) -> TextureViewId {
        self.id
    }
}

impl From<wgpu::TextureView> for TextureView {
    fn from(value: wgpu::TextureView) -> Self {
        TextureView {
            id: TextureViewId::new(),
            value: WgpuTextureView::new(value),
        }
    }
}

impl From<wgpu::SurfaceTexture> for SurfaceTexture {
    fn from(value: wgpu::SurfaceTexture) -> Self {
        SurfaceTexture {
            value: WgpuSurfaceTexture::new(value),
        }
    }
}

impl Deref for TextureView {
    type Target = wgpu::TextureView;

    #[inline]
    fn deref(&self) -> &Self::Target {
        &self.value
    }
}

impl Deref for SurfaceTexture {
    type Target = wgpu::SurfaceTexture;

    #[inline]
    fn deref(&self) -> &Self::Target {
        &self.value
    }
}

define_atomic_id!(SamplerId);

wgpu_wrapper! {
    #[derive(Clone, Debug)]
    struct WgpuSampler(wgpu::Sampler);
}

/// A Sampler defines how a pipeline will sample from a [`TextureView`].
/// They define image filters (including anisotropy) and address (wrapping) modes, among other things.
///
/// May be converted from and dereferences to a wgpu [`Sampler`](wgpu::Sampler).
/// Can be created via [`RenderDevice::create_sampler`](crate::renderer::RenderDevice::create_sampler).
#[derive(Clone, Debug)]
pub struct Sampler {
    id: SamplerId,
    value: WgpuSampler,
}

impl Sampler {
    /// Returns the [`SamplerId`].
    #[inline]
    pub fn id(&self) -> SamplerId {
        self.id
    }
}

impl From<wgpu::Sampler> for Sampler {
    fn from(value: wgpu::Sampler) -> Self {
        Sampler {
            id: SamplerId::new(),
            value: WgpuSampler::new(value),
        }
    }
}

impl Deref for Sampler {
    type Target = wgpu::Sampler;

    #[inline]
    fn deref(&self) -> &Self::Target {
        &self.value
    }
}

/// Stores the [`ImageSamplerDescriptor`] used to create the [`DefaultImageSampler`].
///
/// This is kept as a resource so that [`DefaultImageSampler`] can be recreated on GPU device recovery.
#[derive(Resource, Debug, Clone, Deref)]
pub struct DefaultImageSamplerDescriptor(pub ImageSamplerDescriptor);

/// A rendering resource for the default image sampler which is set during renderer
/// initialization.
///
/// The [`ImagePlugin`](bevy_image::ImagePlugin) can be set during app initialization to change the default
/// image sampler.
#[derive(Resource, Debug, Clone, Deref, DerefMut)]
pub struct DefaultImageSampler(pub(crate) Sampler);

impl FromWorld for DefaultImageSampler {
    fn from_world(world: &mut World) -> Self {
        let descriptor = world.resource::<DefaultImageSamplerDescriptor>();
        let wgpu_descriptor = descriptor.as_wgpu();
        let device = world.resource::<RenderDevice>();
        let sampler = device.create_sampler(&wgpu_descriptor);
        Self(sampler)
    }
}
